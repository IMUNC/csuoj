#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<string.h>
int main(){

	int arr[1002] = {0};
	while (scanf("%s",&arr)!=EOF)
	{
		int  len = 0;
		int i = 0;
		while ()
		{

		}
	}
	return 0;
}